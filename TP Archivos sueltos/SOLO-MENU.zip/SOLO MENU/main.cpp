// PORFAVOR UTILICE ESTE CODIGO CON RESPONSABILIDAD.
// APROBEEEE GUACHOOOSSSSS!!!!

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <string>
#include <time.h>

void menu();
void venta(struct Articulos);
void compra(struct Articulos);
void registrar(struct Articulos);
void consulta(struct Articulos);
void consultamovi(struct Articulos, struct Movimientos);
void avanzadas();
void ordenamiento(struct Articulos);


struct Articulos{
int CodArt;
char NombreArt[30];
int StockActual;
}Articulos;

struct Movimientos{
int CodiArt;
int Cantidad;
char Tipo[30];
char Fecha[30];
}Movimientos;

// DECLARACION DE VARIABLES:
int opcion=0;
char resp='S';

int main(int argc, char *argv[])
{   while(resp=='s' || resp=='S'){
    menute:
    menu();
    fflush(stdin);
    scanf("%d",&opcion);
switch(opcion)
{
    case 1:
    printf("\t||HOLAAAAAAAAAAAAAAAAAAAAAAAAA!!||\n");
    printf("\t||GANOO BOCA||\n");
    printf("\t||LEAAAN TE CABEEE||\n");
    printf("\t||JAJAJAJJAJA||\n");
    printf("\t\n");
    printf("\t\n");
    printf("\t\n");
    printf("\t||JAJAJAJJA||\n");
    break;

    case 2:
    printf("\t||PRUEBA DE MENUUUUUUUU..||\n");
    break;
    printf("\t||GANOO BOCAA||\n");
    case 3:

    break;

    case 4:

    break;

    case 5:

    break;

    case 6:

    break;

    case 7:
//***************************************************************//
    system("CLS");                                               //
    printf("\n\n\n\to-------------------------------------o\n"); //        MUESTRA UN MENSAJE DE CIERRE
    printf("\t||Programa Creado por:  DIEGO GALARZA||\n");       //        QUE NO SIRVE PARA NADA
    printf("\t||UNLa. Licenciatura en Sistemas 2014||\n");       //        QUEDA LINDO
    printf("\t||                                   ||\n");       //                          :)
    printf("\t|| Gracias por utilizar el servicio. ||\n");       //
    printf("\to-------------------------------------o\n");       //
    getch();                                                     //
    return 0;                                                    //
//***************************************************************//
    default:
    //system("cls");
    printf("\nRespuesta INCORRECTA.\n");
    printf("Precione una tecla para continuar");
    getch();
    goto menute;

}//FIN SWITCH(OPCION)

    resp:
    printf("\nDesea volver al MENU? (s/n)\n");
    printf("RESPUESTA: ");
    fflush(stdin);
    scanf("%c",&resp);

    //VERIFICAMOS RESPUESTA CORRECTA
    if(resp!='S' && resp!='s' && resp!='n' &&resp !='N'){
    system("cls");
    printf("\n\t\tRESPUESTA INCORRECTA\n");
    goto resp;
    }//FIN IF "RESP"
}//FIN WHILE "RESP"
//***********************************************************//
system("CLS");                                               //
printf("\n\n\n\to-------------------------------------o\n"); //        MUESTRA UN MENSAJE DE CIERRE
    printf("\t||Programa Creado por:  DIEGO GALARZA||\n");   //        NO SIRVE PARA NADA PERO
    printf("\t||UNLa. Licenciatura en Sistemas 2014||\n");   //        QUEDA LINDO
    printf("\t||                                   ||\n");   //                          :)
    printf("\t|| Gracias por utilizar el servicio. ||\n");   //
    printf("\to-------------------------------------o\n");   //
    getch();                                                 //
    return EXIT_SUCCESS;                                     //
//***********************************************************//
}//FIN MAIN



//PROCEDIMIENTOS:


//**********************************************************
void menu(){
system("cls");
printf("\t�Que accion desea realizar?\n");
printf("\n1- Registrar Producto.\n");
printf("\n2- Realizar Compra.\n");
printf("\n3- Realizar Venta.\n");
printf("\n4- Consultar Stock.\n");
printf("\n5- Consultar Movimientos.\n");
printf("\n6- Opciones Avanzadas.\n");
printf("\n7- Salir\n");
printf("\nOPCION: ");
}
//**********************************************************

//**********************************************************
void avanzadas(){
int opcion2;
system("cls");
     printf("================================================\n");
     printf("||              OPCIONES AVANZADAS            ||\n");
     printf("================================================\n");
     printf("\n\n\t�Que accion desea realizar?\n");
     printf("\n1- Eliminar \"Articulos.DAT\"\n");
     printf("\n2- Eliminar \"Movimientos.DAT\"\n");
     printf("\n3- Ordenar \"Articulos.DAT\"\n");
     printf("\nOPCION: ");
     scanf("%d",&opcion2);
     switch(opcion2){

     case 1:
     remove("Articulos.dat");
     printf("\nArchivo Eliminado\n");
     break;

     case 2:
     remove("Movimientos.dat");
     printf("\nArchivo Eliminado\n");
     break;

     case 3:

     printf("\nArchivo ORDENADO\n.");
     break;

     }//FIN SWITCH()

           }//FIN PROCEDIMIENTO
